﻿namespace Question2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusBar = new System.Windows.Forms.ToolStripProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bhRadio = new System.Windows.Forms.RadioButton();
            this.wmRadio = new System.Windows.Forms.RadioButton();
            this.fdrRadio = new System.Windows.Forms.RadioButton();
            this.rrRadio = new System.Windows.Forms.RadioButton();
            this.wjcRadio = new System.Windows.Forms.RadioButton();
            this.ddeRadio = new System.Windows.Forms.RadioButton();
            this.jbRadio = new System.Windows.Forms.RadioButton();
            this.mvRadio = new System.Windows.Forms.RadioButton();
            this.fpRadio = new System.Windows.Forms.RadioButton();
            this.gwRadio = new System.Windows.Forms.RadioButton();
            this.gwbRadio = new System.Windows.Forms.RadioButton();
            this.jaRadio = new System.Windows.Forms.RadioButton();
            this.boRadio = new System.Windows.Forms.RadioButton();
            this.trRadio = new System.Windows.Forms.RadioButton();
            this.jfkRadio = new System.Windows.Forms.RadioButton();
            this.tjRadio = new System.Windows.Forms.RadioButton();
            this.bhNumBox = new System.Windows.Forms.TextBox();
            this.fdrNumBox = new System.Windows.Forms.TextBox();
            this.wjcNumBox = new System.Windows.Forms.TextBox();
            this.jbNumBox = new System.Windows.Forms.TextBox();
            this.fpNumBox = new System.Windows.Forms.TextBox();
            this.gwbNumBox = new System.Windows.Forms.TextBox();
            this.boNumBox = new System.Windows.Forms.TextBox();
            this.jfkNumBox = new System.Windows.Forms.TextBox();
            this.wmNumBox = new System.Windows.Forms.TextBox();
            this.rrNumBox = new System.Windows.Forms.TextBox();
            this.ddeNumBox = new System.Windows.Forms.TextBox();
            this.mvNumBox = new System.Windows.Forms.TextBox();
            this.gwNumBox = new System.Windows.Forms.TextBox();
            this.jaNumBox = new System.Windows.Forms.TextBox();
            this.trNumBox = new System.Windows.Forms.TextBox();
            this.tjNumBox = new System.Windows.Forms.TextBox();
            this.filterBox = new System.Windows.Forms.GroupBox();
            this.fedRadio = new System.Windows.Forms.RadioButton();
            this.demoRepubRadio = new System.Windows.Forms.RadioButton();
            this.repubRadio = new System.Windows.Forms.RadioButton();
            this.demoRadio = new System.Windows.Forms.RadioButton();
            this.allRadio = new System.Windows.Forms.RadioButton();
            this.urlBox = new System.Windows.Forms.GroupBox();
            this.wikiBrowser = new System.Windows.Forms.WebBrowser();
            this.imgBox = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.presidentsList = new System.Windows.Forms.ImageList(this.components);
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.statusStrip1.SuspendLayout();
            this.filterBox.SuspendLayout();
            this.urlBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusBar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 539);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(984, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusBar
            // 
            this.statusBar.Maximum = 120;
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(700, 16);
            this.statusBar.Value = 120;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            // 
            // bhRadio
            // 
            this.bhRadio.AutoSize = true;
            this.bhRadio.Checked = true;
            this.bhRadio.Location = new System.Drawing.Point(13, 13);
            this.bhRadio.Name = "bhRadio";
            this.bhRadio.Size = new System.Drawing.Size(110, 17);
            this.bhRadio.TabIndex = 1;
            this.bhRadio.TabStop = true;
            this.bhRadio.Text = "Benjamin Harrison";
            this.bhRadio.UseVisualStyleBackColor = true;
            // 
            // wmRadio
            // 
            this.wmRadio.AutoSize = true;
            this.wmRadio.Location = new System.Drawing.Point(182, 13);
            this.wmRadio.Name = "wmRadio";
            this.wmRadio.Size = new System.Drawing.Size(104, 17);
            this.wmRadio.TabIndex = 2;
            this.wmRadio.Text = "William McKinley";
            this.wmRadio.UseVisualStyleBackColor = true;
            // 
            // fdrRadio
            // 
            this.fdrRadio.AutoSize = true;
            this.fdrRadio.Location = new System.Drawing.Point(13, 36);
            this.fdrRadio.Name = "fdrRadio";
            this.fdrRadio.Size = new System.Drawing.Size(124, 17);
            this.fdrRadio.TabIndex = 3;
            this.fdrRadio.Text = "Franklin D Roosevelt";
            this.fdrRadio.UseVisualStyleBackColor = true;
            // 
            // rrRadio
            // 
            this.rrRadio.AutoSize = true;
            this.rrRadio.Location = new System.Drawing.Point(182, 36);
            this.rrRadio.Name = "rrRadio";
            this.rrRadio.Size = new System.Drawing.Size(100, 17);
            this.rrRadio.TabIndex = 4;
            this.rrRadio.Text = "Ronald Reagan";
            this.rrRadio.UseVisualStyleBackColor = true;
            // 
            // wjcRadio
            // 
            this.wjcRadio.AutoSize = true;
            this.wjcRadio.Location = new System.Drawing.Point(12, 59);
            this.wjcRadio.Name = "wjcRadio";
            this.wjcRadio.Size = new System.Drawing.Size(101, 17);
            this.wjcRadio.TabIndex = 5;
            this.wjcRadio.Text = "William J Clinton";
            this.wjcRadio.UseVisualStyleBackColor = true;
            // 
            // ddeRadio
            // 
            this.ddeRadio.AutoSize = true;
            this.ddeRadio.Location = new System.Drawing.Point(182, 59);
            this.ddeRadio.Name = "ddeRadio";
            this.ddeRadio.Size = new System.Drawing.Size(127, 17);
            this.ddeRadio.TabIndex = 6;
            this.ddeRadio.Text = "Dwight D Eisenhower";
            this.ddeRadio.UseVisualStyleBackColor = true;
            // 
            // jbRadio
            // 
            this.jbRadio.AutoSize = true;
            this.jbRadio.Location = new System.Drawing.Point(13, 82);
            this.jbRadio.Name = "jbRadio";
            this.jbRadio.Size = new System.Drawing.Size(107, 17);
            this.jbRadio.TabIndex = 7;
            this.jbRadio.Text = "James Buchanan";
            this.jbRadio.UseVisualStyleBackColor = true;
            // 
            // mvRadio
            // 
            this.mvRadio.AutoSize = true;
            this.mvRadio.Location = new System.Drawing.Point(182, 82);
            this.mvRadio.Name = "mvRadio";
            this.mvRadio.Size = new System.Drawing.Size(104, 17);
            this.mvRadio.TabIndex = 8;
            this.mvRadio.Text = "Martin VanBuren";
            this.mvRadio.UseVisualStyleBackColor = true;
            // 
            // fpRadio
            // 
            this.fpRadio.AutoSize = true;
            this.fpRadio.Location = new System.Drawing.Point(13, 105);
            this.fpRadio.Name = "fpRadio";
            this.fpRadio.Size = new System.Drawing.Size(95, 17);
            this.fpRadio.TabIndex = 9;
            this.fpRadio.Text = "Franklin Pierce";
            this.fpRadio.UseVisualStyleBackColor = true;
            // 
            // gwRadio
            // 
            this.gwRadio.AutoSize = true;
            this.gwRadio.Location = new System.Drawing.Point(182, 105);
            this.gwRadio.Name = "gwRadio";
            this.gwRadio.Size = new System.Drawing.Size(120, 17);
            this.gwRadio.TabIndex = 10;
            this.gwRadio.Text = "George Washington";
            this.gwRadio.UseVisualStyleBackColor = true;
            // 
            // gwbRadio
            // 
            this.gwbRadio.AutoSize = true;
            this.gwbRadio.Location = new System.Drawing.Point(13, 128);
            this.gwbRadio.Name = "gwbRadio";
            this.gwbRadio.Size = new System.Drawing.Size(101, 17);
            this.gwbRadio.TabIndex = 11;
            this.gwbRadio.Text = "George W Bush";
            this.gwbRadio.UseVisualStyleBackColor = true;
            // 
            // jaRadio
            // 
            this.jaRadio.AutoSize = true;
            this.jaRadio.Location = new System.Drawing.Point(182, 128);
            this.jaRadio.Name = "jaRadio";
            this.jaRadio.Size = new System.Drawing.Size(83, 17);
            this.jaRadio.TabIndex = 12;
            this.jaRadio.Text = "John Adams";
            this.jaRadio.UseVisualStyleBackColor = true;
            // 
            // boRadio
            // 
            this.boRadio.AutoSize = true;
            this.boRadio.Location = new System.Drawing.Point(13, 151);
            this.boRadio.Name = "boRadio";
            this.boRadio.Size = new System.Drawing.Size(96, 17);
            this.boRadio.TabIndex = 13;
            this.boRadio.Text = "Barack Obama";
            this.boRadio.UseVisualStyleBackColor = true;
            // 
            // trRadio
            // 
            this.trRadio.AutoSize = true;
            this.trRadio.Location = new System.Drawing.Point(182, 151);
            this.trRadio.Name = "trRadio";
            this.trRadio.Size = new System.Drawing.Size(122, 17);
            this.trRadio.TabIndex = 14;
            this.trRadio.Text = "Theodore Roosevelt";
            this.trRadio.UseVisualStyleBackColor = true;
            // 
            // jfkRadio
            // 
            this.jfkRadio.AutoSize = true;
            this.jfkRadio.Location = new System.Drawing.Point(13, 174);
            this.jfkRadio.Name = "jfkRadio";
            this.jfkRadio.Size = new System.Drawing.Size(102, 17);
            this.jfkRadio.TabIndex = 15;
            this.jfkRadio.Text = "John F Kennedy";
            this.jfkRadio.UseVisualStyleBackColor = true;
            // 
            // tjRadio
            // 
            this.tjRadio.AutoSize = true;
            this.tjRadio.Location = new System.Drawing.Point(182, 174);
            this.tjRadio.Name = "tjRadio";
            this.tjRadio.Size = new System.Drawing.Size(109, 17);
            this.tjRadio.TabIndex = 16;
            this.tjRadio.Text = "Thomas Jefferson";
            this.tjRadio.UseVisualStyleBackColor = true;
            // 
            // bhNumBox
            // 
            this.bhNumBox.Location = new System.Drawing.Point(141, 13);
            this.bhNumBox.Name = "bhNumBox";
            this.bhNumBox.Size = new System.Drawing.Size(30, 20);
            this.bhNumBox.TabIndex = 17;
            this.bhNumBox.Text = "0";
            // 
            // fdrNumBox
            // 
            this.fdrNumBox.Location = new System.Drawing.Point(141, 36);
            this.fdrNumBox.Name = "fdrNumBox";
            this.fdrNumBox.Size = new System.Drawing.Size(30, 20);
            this.fdrNumBox.TabIndex = 18;
            this.fdrNumBox.Text = "0";
            // 
            // wjcNumBox
            // 
            this.wjcNumBox.Location = new System.Drawing.Point(141, 59);
            this.wjcNumBox.Name = "wjcNumBox";
            this.wjcNumBox.Size = new System.Drawing.Size(30, 20);
            this.wjcNumBox.TabIndex = 19;
            this.wjcNumBox.Text = "0";
            // 
            // jbNumBox
            // 
            this.jbNumBox.Location = new System.Drawing.Point(141, 82);
            this.jbNumBox.Name = "jbNumBox";
            this.jbNumBox.Size = new System.Drawing.Size(30, 20);
            this.jbNumBox.TabIndex = 20;
            this.jbNumBox.Text = "0";
            // 
            // fpNumBox
            // 
            this.fpNumBox.Location = new System.Drawing.Point(141, 104);
            this.fpNumBox.Name = "fpNumBox";
            this.fpNumBox.Size = new System.Drawing.Size(30, 20);
            this.fpNumBox.TabIndex = 21;
            this.fpNumBox.Text = "0";
            // 
            // gwbNumBox
            // 
            this.gwbNumBox.Location = new System.Drawing.Point(141, 128);
            this.gwbNumBox.Name = "gwbNumBox";
            this.gwbNumBox.Size = new System.Drawing.Size(30, 20);
            this.gwbNumBox.TabIndex = 22;
            this.gwbNumBox.Text = "0";
            // 
            // boNumBox
            // 
            this.boNumBox.Location = new System.Drawing.Point(141, 150);
            this.boNumBox.Name = "boNumBox";
            this.boNumBox.Size = new System.Drawing.Size(30, 20);
            this.boNumBox.TabIndex = 23;
            this.boNumBox.Text = "0";
            // 
            // jfkNumBox
            // 
            this.jfkNumBox.Location = new System.Drawing.Point(141, 174);
            this.jfkNumBox.Name = "jfkNumBox";
            this.jfkNumBox.Size = new System.Drawing.Size(30, 20);
            this.jfkNumBox.TabIndex = 24;
            this.jfkNumBox.Text = "0";
            // 
            // wmNumBox
            // 
            this.wmNumBox.Location = new System.Drawing.Point(311, 12);
            this.wmNumBox.Name = "wmNumBox";
            this.wmNumBox.Size = new System.Drawing.Size(30, 20);
            this.wmNumBox.TabIndex = 25;
            this.wmNumBox.Text = "0";
            // 
            // rrNumBox
            // 
            this.rrNumBox.Location = new System.Drawing.Point(311, 35);
            this.rrNumBox.Name = "rrNumBox";
            this.rrNumBox.Size = new System.Drawing.Size(30, 20);
            this.rrNumBox.TabIndex = 26;
            this.rrNumBox.Text = "0";
            // 
            // ddeNumBox
            // 
            this.ddeNumBox.Location = new System.Drawing.Point(311, 58);
            this.ddeNumBox.Name = "ddeNumBox";
            this.ddeNumBox.Size = new System.Drawing.Size(30, 20);
            this.ddeNumBox.TabIndex = 27;
            this.ddeNumBox.Text = "0";
            // 
            // mvNumBox
            // 
            this.mvNumBox.Location = new System.Drawing.Point(311, 82);
            this.mvNumBox.Name = "mvNumBox";
            this.mvNumBox.Size = new System.Drawing.Size(30, 20);
            this.mvNumBox.TabIndex = 28;
            this.mvNumBox.Text = "0";
            // 
            // gwNumBox
            // 
            this.gwNumBox.Location = new System.Drawing.Point(311, 105);
            this.gwNumBox.Name = "gwNumBox";
            this.gwNumBox.Size = new System.Drawing.Size(30, 20);
            this.gwNumBox.TabIndex = 29;
            this.gwNumBox.Text = "0";
            // 
            // jaNumBox
            // 
            this.jaNumBox.Location = new System.Drawing.Point(311, 128);
            this.jaNumBox.Name = "jaNumBox";
            this.jaNumBox.Size = new System.Drawing.Size(30, 20);
            this.jaNumBox.TabIndex = 30;
            this.jaNumBox.Text = "0";
            // 
            // trNumBox
            // 
            this.trNumBox.Location = new System.Drawing.Point(311, 151);
            this.trNumBox.Name = "trNumBox";
            this.trNumBox.Size = new System.Drawing.Size(30, 20);
            this.trNumBox.TabIndex = 31;
            this.trNumBox.Text = "0";
            // 
            // tjNumBox
            // 
            this.tjNumBox.Location = new System.Drawing.Point(311, 174);
            this.tjNumBox.Name = "tjNumBox";
            this.tjNumBox.Size = new System.Drawing.Size(30, 20);
            this.tjNumBox.TabIndex = 32;
            this.tjNumBox.Text = "0";
            // 
            // filterBox
            // 
            this.filterBox.Controls.Add(this.fedRadio);
            this.filterBox.Controls.Add(this.demoRepubRadio);
            this.filterBox.Controls.Add(this.repubRadio);
            this.filterBox.Controls.Add(this.demoRadio);
            this.filterBox.Controls.Add(this.allRadio);
            this.filterBox.Location = new System.Drawing.Point(193, 217);
            this.filterBox.Name = "filterBox";
            this.filterBox.Size = new System.Drawing.Size(148, 143);
            this.filterBox.TabIndex = 33;
            this.filterBox.TabStop = false;
            this.filterBox.Text = "Filter";
            // 
            // fedRadio
            // 
            this.fedRadio.AutoSize = true;
            this.fedRadio.Location = new System.Drawing.Point(7, 116);
            this.fedRadio.Name = "fedRadio";
            this.fedRadio.Size = new System.Drawing.Size(70, 17);
            this.fedRadio.TabIndex = 4;
            this.fedRadio.Text = "Federalist";
            this.fedRadio.UseVisualStyleBackColor = true;
            // 
            // demoRepubRadio
            // 
            this.demoRepubRadio.AutoSize = true;
            this.demoRepubRadio.Location = new System.Drawing.Point(7, 92);
            this.demoRepubRadio.Name = "demoRepubRadio";
            this.demoRepubRadio.Size = new System.Drawing.Size(136, 17);
            this.demoRepubRadio.TabIndex = 3;
            this.demoRepubRadio.Text = "Democratic-Republican";
            this.demoRepubRadio.UseVisualStyleBackColor = true;
            // 
            // repubRadio
            // 
            this.repubRadio.AutoSize = true;
            this.repubRadio.Location = new System.Drawing.Point(7, 68);
            this.repubRadio.Name = "repubRadio";
            this.repubRadio.Size = new System.Drawing.Size(79, 17);
            this.repubRadio.TabIndex = 2;
            this.repubRadio.Text = "Republican";
            this.repubRadio.UseVisualStyleBackColor = true;
            // 
            // demoRadio
            // 
            this.demoRadio.AutoSize = true;
            this.demoRadio.Location = new System.Drawing.Point(7, 44);
            this.demoRadio.Name = "demoRadio";
            this.demoRadio.Size = new System.Drawing.Size(71, 17);
            this.demoRadio.TabIndex = 1;
            this.demoRadio.Text = "Democrat";
            this.demoRadio.UseVisualStyleBackColor = true;
            // 
            // allRadio
            // 
            this.allRadio.AutoSize = true;
            this.allRadio.Checked = true;
            this.allRadio.Location = new System.Drawing.Point(7, 20);
            this.allRadio.Name = "allRadio";
            this.allRadio.Size = new System.Drawing.Size(36, 17);
            this.allRadio.TabIndex = 0;
            this.allRadio.TabStop = true;
            this.allRadio.Text = "All";
            this.allRadio.UseVisualStyleBackColor = true;
            // 
            // urlBox
            // 
            this.urlBox.Controls.Add(this.wikiBrowser);
            this.urlBox.Location = new System.Drawing.Point(347, 13);
            this.urlBox.Name = "urlBox";
            this.urlBox.Size = new System.Drawing.Size(637, 459);
            this.urlBox.TabIndex = 34;
            this.urlBox.TabStop = false;
            // 
            // wikiBrowser
            // 
            this.wikiBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wikiBrowser.Location = new System.Drawing.Point(3, 16);
            this.wikiBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.wikiBrowser.Name = "wikiBrowser";
            this.wikiBrowser.Size = new System.Drawing.Size(631, 440);
            this.wikiBrowser.TabIndex = 0;
            // 
            // imgBox
            // 
            this.imgBox.Image = global::Question2.Properties.Resources.BenjaminHarrison;
            this.imgBox.Location = new System.Drawing.Point(13, 217);
            this.imgBox.Name = "imgBox";
            this.imgBox.Size = new System.Drawing.Size(174, 194);
            this.imgBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgBox.TabIndex = 35;
            this.imgBox.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Enabled = false;
            this.exitButton.Location = new System.Drawing.Point(856, 492);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 36;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // presidentsList
            // 
            this.presidentsList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("presidentsList.ImageStream")));
            this.presidentsList.TransparentColor = System.Drawing.Color.Transparent;
            this.presidentsList.Images.SetKeyName(0, "BarackObama.png");
            this.presidentsList.Images.SetKeyName(1, "BenjaminHarrison.jpeg");
            this.presidentsList.Images.SetKeyName(2, "DwightDEisenhower.jpeg");
            this.presidentsList.Images.SetKeyName(3, "FranklinDRoosevelt.jpeg");
            this.presidentsList.Images.SetKeyName(4, "FranklinPierce.jpeg");
            this.presidentsList.Images.SetKeyName(5, "GeorgeWashington.jpeg");
            this.presidentsList.Images.SetKeyName(6, "GeorgeWBush.jpeg");
            this.presidentsList.Images.SetKeyName(7, "JamesBuchanan.jpeg");
            this.presidentsList.Images.SetKeyName(8, "JohnAdams.jpeg");
            this.presidentsList.Images.SetKeyName(9, "JohnFKennedy.jpeg");
            this.presidentsList.Images.SetKeyName(10, "MartinVanBuren.jpeg");
            this.presidentsList.Images.SetKeyName(11, "RonaldReagan.jpeg");
            this.presidentsList.Images.SetKeyName(12, "TheodoreRoosevelt.jpeg");
            this.presidentsList.Images.SetKeyName(13, "ThomasJefferson.jpeg");
            this.presidentsList.Images.SetKeyName(14, "WilliamJClinton.jpeg");
            this.presidentsList.Images.SetKeyName(15, "WilliamMcKinley.jpeg");
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.ControlBox = false;
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.imgBox);
            this.Controls.Add(this.urlBox);
            this.Controls.Add(this.filterBox);
            this.Controls.Add(this.tjNumBox);
            this.Controls.Add(this.trNumBox);
            this.Controls.Add(this.jaNumBox);
            this.Controls.Add(this.gwNumBox);
            this.Controls.Add(this.mvNumBox);
            this.Controls.Add(this.ddeNumBox);
            this.Controls.Add(this.rrNumBox);
            this.Controls.Add(this.wmNumBox);
            this.Controls.Add(this.jfkNumBox);
            this.Controls.Add(this.boNumBox);
            this.Controls.Add(this.gwbNumBox);
            this.Controls.Add(this.fpNumBox);
            this.Controls.Add(this.jbNumBox);
            this.Controls.Add(this.wjcNumBox);
            this.Controls.Add(this.fdrNumBox);
            this.Controls.Add(this.bhNumBox);
            this.Controls.Add(this.tjRadio);
            this.Controls.Add(this.jfkRadio);
            this.Controls.Add(this.trRadio);
            this.Controls.Add(this.boRadio);
            this.Controls.Add(this.jaRadio);
            this.Controls.Add(this.gwbRadio);
            this.Controls.Add(this.gwRadio);
            this.Controls.Add(this.fpRadio);
            this.Controls.Add(this.mvRadio);
            this.Controls.Add(this.jbRadio);
            this.Controls.Add(this.ddeRadio);
            this.Controls.Add(this.wjcRadio);
            this.Controls.Add(this.rrRadio);
            this.Controls.Add(this.fdrRadio);
            this.Controls.Add(this.wmRadio);
            this.Controls.Add(this.bhRadio);
            this.Controls.Add(this.statusStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.filterBox.ResumeLayout(false);
            this.filterBox.PerformLayout();
            this.urlBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar statusBar;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.RadioButton bhRadio;
        private System.Windows.Forms.RadioButton wmRadio;
        private System.Windows.Forms.RadioButton fdrRadio;
        private System.Windows.Forms.RadioButton rrRadio;
        private System.Windows.Forms.RadioButton wjcRadio;
        private System.Windows.Forms.RadioButton ddeRadio;
        private System.Windows.Forms.RadioButton jbRadio;
        private System.Windows.Forms.RadioButton mvRadio;
        private System.Windows.Forms.RadioButton fpRadio;
        private System.Windows.Forms.RadioButton gwRadio;
        private System.Windows.Forms.RadioButton gwbRadio;
        private System.Windows.Forms.RadioButton jaRadio;
        private System.Windows.Forms.RadioButton boRadio;
        private System.Windows.Forms.RadioButton trRadio;
        private System.Windows.Forms.RadioButton jfkRadio;
        private System.Windows.Forms.RadioButton tjRadio;
        private System.Windows.Forms.TextBox bhNumBox;
        private System.Windows.Forms.TextBox fdrNumBox;
        private System.Windows.Forms.TextBox wjcNumBox;
        private System.Windows.Forms.TextBox jbNumBox;
        private System.Windows.Forms.TextBox fpNumBox;
        private System.Windows.Forms.TextBox gwbNumBox;
        private System.Windows.Forms.TextBox boNumBox;
        private System.Windows.Forms.TextBox jfkNumBox;
        private System.Windows.Forms.TextBox wmNumBox;
        private System.Windows.Forms.TextBox rrNumBox;
        private System.Windows.Forms.TextBox ddeNumBox;
        private System.Windows.Forms.TextBox mvNumBox;
        private System.Windows.Forms.TextBox gwNumBox;
        private System.Windows.Forms.TextBox jaNumBox;
        private System.Windows.Forms.TextBox trNumBox;
        private System.Windows.Forms.TextBox tjNumBox;
        private System.Windows.Forms.GroupBox filterBox;
        private System.Windows.Forms.RadioButton fedRadio;
        private System.Windows.Forms.RadioButton demoRepubRadio;
        private System.Windows.Forms.RadioButton repubRadio;
        private System.Windows.Forms.RadioButton demoRadio;
        private System.Windows.Forms.RadioButton allRadio;
        private System.Windows.Forms.GroupBox urlBox;
        private System.Windows.Forms.PictureBox imgBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ImageList presidentsList;
        private System.Windows.Forms.WebBrowser wikiBrowser;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.ToolTip toolTip;
    }
}

